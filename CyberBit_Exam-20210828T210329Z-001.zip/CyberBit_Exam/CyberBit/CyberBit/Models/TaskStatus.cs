﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CyberBit.Models
{
    public enum TaskStatus
    {
        Done = 1,
        Late = 2,
        OnTime = 3
    }
}
